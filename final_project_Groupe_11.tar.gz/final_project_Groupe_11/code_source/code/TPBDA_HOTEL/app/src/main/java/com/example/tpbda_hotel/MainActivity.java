package com.example.tpbda_hotel;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SearchView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private BDManagement databaseManager;
    private RelativeLayout relativeLayout;
    private ListView listView;
    private ArrayList<String> hotel;
    ArrayAdapter<String> hotelItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        databaseManager = new BDManagement(this);
        hotel = databaseManager.getHotel();
        LayoutInflater inflater = getLayoutInflater();
        relativeLayout = (RelativeLayout) inflater.inflate(R.layout.activity_main, null);
        setTitle("Trouver un hotel");

        setContentView(relativeLayout);


        hotelItems = new ArrayAdapter<String>(this, R.layout.items_layout, R.id.item, hotel);
        listView = (ListView) findViewById(R.id.listItem);
        listView.setAdapter(hotelItems);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(MainActivity.this, MapsActivity.class);
                intent.putExtra("_hotel", hotelItems.getItem(i));
                startActivity(intent);
            }
        });

        databaseManager.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.hotel,menu);
        MenuItem menuItem = menu.findItem(R.id.search);
        SearchView searchView = (SearchView) menuItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                hotelItems.getFilter().filter(newText);
                return false;
            }
        });
        return  super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){

        switch (item.getItemId()){
            case R.id.search:
                /*DO SEARCH*/

                return true;
            case R.id.about:
                /*PRINT ABOUT*/

                return true;
            case R.id.help:
                /*PRINT HELP*/

                return true;


        }
        return super.onOptionsItemSelected(item);
    }
}
