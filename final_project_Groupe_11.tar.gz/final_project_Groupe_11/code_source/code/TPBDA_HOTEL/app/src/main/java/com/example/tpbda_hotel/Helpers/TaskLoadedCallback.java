package com.example.tpbda_hotel.Helpers;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}
